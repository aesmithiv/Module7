import { Routes, Route } from 'react-router-dom';
import Home from '../pages/Home';
import Login from '../pages/Login';
import BitcoinPage from '../pages/BitcoinPage';
import PageNotFound from '../pages/PageNotFound';

export default function AppRoutes(props) {
  return (
    <Routes>
      <Route index element={<Home {...props} />} />
      <Route path="/login" element={<Login {...props} />} />
      <Route path="/bitcoin" element={<BitcoinPage {...props} />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
}
