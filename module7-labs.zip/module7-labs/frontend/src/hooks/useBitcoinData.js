import { useState, useEffect } from 'react';

export function useBitcoinData() {
  const [currency, setCurrency] = useState('USD');
  const [price, setPrice] = useState(0);

  useEffect(() => {
    fetch(`http://localhost:3000/api/bitcoin/${currency}`)
      .then(res => res.json())
      .then(data => {
        const val = data.bitcoin?.[currency.toLowerCase()] ?? 0;
        setPrice(val);
      });
  }, [currency]);

  return { currency, setCurrency, price };
}
