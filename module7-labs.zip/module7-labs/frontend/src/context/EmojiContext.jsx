import { createContext, useState } from 'react';

export const EmojiContext = createContext();

export function EmojiProvider({ children }) {
  const [emoji, setEmoji] = useState('😊');
  const toggleEmoji = () => setEmoji(prev => (prev === '😊' ? '😎' : '😊'));

  return (
    <EmojiContext.Provider value={{ emoji, toggleEmoji }}>
      {children}
    </EmojiContext.Provider>
  );
}
