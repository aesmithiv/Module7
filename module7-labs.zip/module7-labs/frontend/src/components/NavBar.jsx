import { NavLink } from 'react-router-dom';

export default function NavBar() {
  return (
    <nav style={{ padding: '1rem', borderBottom: '1px solid #ccc' }}>
      <NavLink to="/" style={{ marginRight: '1rem' }}>Home</NavLink>
      <NavLink to="/login" style={{ marginRight: '1rem' }}>Login</NavLink>
      <NavLink to="/bitcoin">Bitcoin Rates</NavLink>
    </nav>
  );
}
