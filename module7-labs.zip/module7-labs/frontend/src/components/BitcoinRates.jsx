import { useContext } from 'react';
import { useBitcoinData } from '../hooks/useBitcoinData';
import { EmojiContext } from '../context/EmojiContext';

const currencies = ['USD', 'AUD', 'NZD', 'GBP', 'EUR', 'SGD'];

export default function BitcoinRates() {
  const { currency, price, setCurrency } = useBitcoinData();
  const { emoji, toggleEmoji } = useContext(EmojiContext);

  return (
    <div style={{ padding: '1rem' }}>
      <h3>Bitcoin Price in {currency}: ${price}</h3>
      <p>Current Mood: {emoji}</p>
      <button onClick={toggleEmoji}>Change Mood</button>
      <br />
      <label>Select currency: </label>
      <select value={currency} onChange={(e) => setCurrency(e.target.value)}>
        {currencies.map((curr) => (
          <option key={curr} value={curr}>{curr}</option>
        ))}
      </select>
    </div>
  );
}
