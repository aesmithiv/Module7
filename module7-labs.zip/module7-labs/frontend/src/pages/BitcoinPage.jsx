import BitcoinRates from '../components/BitcoinRates';

export default function BitcoinPage() {
  return (
    <div>
      <h1>📈 Bitcoin Rates</h1>
      <BitcoinRates />
    </div>
  );
}
