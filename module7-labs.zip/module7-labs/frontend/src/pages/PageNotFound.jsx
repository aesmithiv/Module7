import { Link } from 'react-router-dom';

export default function PageNotFound() {
  return (
    <div style={{ padding: '2rem' }}>
      <h2>404 - Page Not Found</h2>
      <p>What you’re looking for isn’t here.</p>
      <Link to="/">← Go Home</Link>
    </div>
  );
}
