import AppRoutes from './routes/AppRoutes';
import { EmojiProvider } from './context/EmojiContext';
import NavBar from './components/NavBar';

export default function App() {
  return (
    <EmojiProvider>
      <NavBar />
      <AppRoutes />
    </EmojiProvider>
  );
}
