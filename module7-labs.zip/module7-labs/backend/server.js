const express = require('express');
const cors = require('cors');
const { getBitcoinRate } = require('./data/bitcoin');

const app = express();
const PORT = 3000;

app.use(cors());

app.get('/api/bitcoin/:currency', (req, res) => {
  const currency = req.params.currency;
  const rate = getBitcoinRate(currency);
  res.json({ bitcoin: { [currency.toLowerCase()]: rate } });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
