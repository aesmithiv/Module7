const mockRates = {
    usd: 68000,
    aud: 102000,
    nzd: 97000,
    gbp: 54000,
    eur: 61000,
    sgd: 91000,
  };
  
  function getBitcoinRate(currency) {
    return mockRates[currency.toLowerCase()] || 0;
  }
  
  module.exports = {
    getBitcoinRate,
  };
  